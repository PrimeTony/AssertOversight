package com.example.cams

import android.content.res.Resources
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.bottomsheet.BottomSheetDialog

class MapActivity : AppCompatActivity(),OnMapReadyCallback {
    private var mGoogleMap:GoogleMap? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)
        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
      mGoogleMap=googleMap
        try {
            val success = mGoogleMap?.setMapStyle(
                MapStyleOptions.loadRawResourceStyle(
                    this, R.raw.snazzy_map_style
                )
            )

            if (success == false) {
                // Handle the case where the style wasn't successfully applied
                // e.g., log the error or notify the user
            }
        } catch (e: Resources.NotFoundException) {
            // Handle the exception if the JSON file is not found
            e.printStackTrace()
        }

        // my zoom options on pretoria
        val pretoria = LatLng(-25.7479, 28.2293)
        mGoogleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(pretoria,12f))
    }

    fun showBottomSheet(view: View) {
        val dialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.bottomsheet,null)
        //val btnclose = view.findViewById<>() close dismiss
        dialog.setContentView(view)
        dialog.setCancelable(true)
        dialog.show()
    }
}
